export const environment = {
  production: false,
   // URL of development API
   apiUrl: 'https://10.81.49.83:442',
   apiController: '/api/IcsAdmin',
   apiUserName:'icsadmin',
   apiPassword:'@icsadmin'
};

