$(document).ready(function(){
	function initializeCustomSelect(){
		$('select').each(function(){
			var select_class = $(this).attr('class');
			if(select_class !== 'customSelect_multiple'){
				$(this).selectmenu({  
					classes: {
						"ui-selectmenu-button": select_class
					}
				});//.selectmenu('menuWidget').addClass('overflow');
			}
		});
	}
	
	initializeCustomSelect();
	
	$('.alert_position').click(function(){
		$('.alert_cont').fadeIn();
	});
	
	$('.alert_position').dblclick(function(){
		window.location = 'machine_details.html';
	});
	
	$('.icon_fault_01').click(function(){
		$('.alert_machineDetails').fadeIn();
	});
	
	//var valeur_1 = 0;
	//var time_1 = 10;
	//var rate_1 = 6;
	//setInterval(function(){
	//	if(valeur_1 < 100){
	//		valeur_1 = valeur_1 + 10;
	//		time_1 = '0' + (time_1 - 1);
	//		if(rate_1 < 2){
	//			rate_1 = 6;
	//		}
	//		rate_1 = '0' + (rate_1 - 1);
	//	}else{
	//		valeur_1 = 0;
	//		time_1 = 10;
	//		rate_1 = 6;
	//	}
	//	updateProgress(valeur_1, time_1, rate_1, '01');
	//}, 5000);	
	
	//var valeur_2 = 0;
	//var time_2 = 10;
	//var rate_2 = 6;
	//setInterval(function(){
	//	if(valeur_2 < 100){
	//		valeur_2 = valeur_2 + 10;
	//		time_2 = '0' + (time_2 - 1);
	//		if(rate_2 < 2){
	//			rate_2 = 6;
	//		}
	//		rate_2 = '0' + (rate_2 - 1);
	//	}else{
	//		valeur_2 = 0;
	//		time_2 = 10;
	//		rate_2 = 6;
	//	}
	//	updateProgress(valeur_2, time_2, rate_2, '02');
	//}, 7500);
	
	//var valeur_3 = 0;
	//var time_3 = 10;
	//var rate_3 = 6;
	//setInterval(function(){
	//	if(valeur_3 < 100){
	//		valeur_3 = valeur_3 + 10;
	//		time_3 = '0' + (time_3 - 1);
	//		if(rate_3 < 2){
	//			rate_3 = 6;
	//		}
	//		rate_3 = '0' + (rate_3 - 1);
	//	}else{
	//		valeur_3 = 0;
	//		time_3 = 10;
	//		rate_3 = 6;
	//	}
	//	updateProgress(valeur_3, time_3, rate_3, '03');
	//}, 12000);
	
	//function updateProgress(valeur, time, rate, count){
	//	$('#progress_'+ count).css('width', valeur+'%').attr('aria-valuenow', valeur);
	//	$('#progress_'+ count).parent().parent().find('.progress_val').text(valeur+'%');
		
	//	$('#time_'+ count).text(time+' Hrs');
	//	$('#rate_'+ count).text(rate+'%');
	//}
	
	
	//var valeur_4 = 82;
	//var availability = 88;
	//var quality = 95;
	//var performance = 92;
	//setInterval(function(){
	//	if(valeur_4 < 86){
	//		valeur_4 = valeur_4 + 1;
	//		availability = availability + 1;
	//		quality = quality + 1;
	//		performance = performance + 1;
	//	}else{
	//		valeur_4 = 82;
	//		availability = 88;
	//		quality = 95;
	//		performance = 92;
	//	}
	//	updateProgress_effectiveness(valeur_4, availability, quality, performance);
	//}, 3000);
	
	
	//function updateProgress_effectiveness(valeur_4, availability, quality, performance){
	//	$('#progress_effectiveness').css('width', valeur_4+'%').attr('aria-valuenow', valeur_4);
	//	$('#progress_effectiveness').parent().parent().find('.progress_val').text(valeur_4+'%');
		
	//	$('#span_availability').text(availability+'%');
	//	$('#span_quality').text(quality+'%');
	//	$('#span_performance').text(performance+'%');
	//}
	
	
	
	function expandColumn(){
		$('.machine_cont').removeClass('align_right');
		$('.tile_fixedWidth').animate({'width':'15px', 'right': '-8px'}, 1000, function(){
			$('.tab_ul, .tab-content').css('visibility', 'hidden');
		});
		$('.column_innerCont').animate({'margin':'0'}, 1000);
	}
	
	$('.icon_toggle').click(function(){
		expandColumn();
	});
});