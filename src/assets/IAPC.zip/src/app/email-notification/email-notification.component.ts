import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-notification',
  templateUrl: './email-notification.component.html',
  styleUrls: ['./email-notification.component.css']
})
export class EmailNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
