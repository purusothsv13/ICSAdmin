import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmailNotificationComponent } from './email-notification.component';
import { EmailNotificationRoutingModule } from './email-notification-routing.module';

@NgModule({
  imports: [
    CommonModule,
    EmailNotificationRoutingModule
  ],
  declarations: [EmailNotificationComponent]
})
export class EmailNotificationModule { }
