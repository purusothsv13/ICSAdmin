export const environment = {
  production: false,
   // URL of development API
   apiUrl: 'http://10.81.49.63',
   apiController: '/api/IcsAdmin',
   apiUserName:'icsadmin',
   apiPassword:'@icsadmin'
};

