import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { NgbPopoverConfig } from '@ng-bootstrap/ng-bootstrap';
import { dashboardModel } from './dashboardICS.model';
import { Chart } from 'chart.js';
import { MediaMatcher } from '@angular/cdk/layout';
import { DatePipe } from '@angular/common'
import { ApiService } from '../service/api.service';
import { appConstants } from '../app.constants';
import { timer } from 'rxjs';
import { Router } from '@angular/router';
/**
 * @title Expansion panel as accordion
 */
@Component({
  selector: 'app-dashboardICS',
  templateUrl: './dashboardICS.component.html',
  styleUrls: ['./dashboardICS.component.css']
})
export class DashboardComponent implements OnInit {

  get data():string {
    return this.apiService.serviceData;
}
set data(value: string) {
    this.apiService.serviceData = value;
}

  public dashboardModel: dashboardModel;
  public loading = false;
  private _mobileQueryListener: () => void;
  mobileQuery: MediaQueryList;
  statusFilter: string[] = [];
  systemFilter: string[] = [];
  frequencyFilter: string[] = [];
  hasChild: number = 0;
  step = 1;
  //today = Date.now();
  constants = appConstants;

  constructor(config: NgbPopoverConfig, changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher, public datepipe: DatePipe, private apiService: ApiService, private router: Router) {
    this.dashboardModel = new dashboardModel();
    // customize default values of popovers used by this component tree
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    config.placement = ["left", "right"];
    config.triggers = 'hover';
    config.container = "body";
  }
  memChart = undefined;
  ngOnInit() {
    //this.loading = true;
    const doughnutGraphData = {
      datasets: [{
        borderWidth: [0, 0, 0],
        data: [],
        backgroundColor: ['#32CD32', '#FF0000', 'rgb(255, 215, 64)'],
      }],

    };

    const ctx = document.getElementById('mChart');

    var options = {
      cutoutPercentage: 30,
      tooltips: {
        enabled: false
      },
      layout: {
        padding: {
          left: 0,
          right: 0,
          top: -15,
          bottom: 0
        }
      }
    };

    this.memChart = new Chart(ctx, {
      type: 'doughnut',
      data: doughnutGraphData,
      options: options
    });

    const pieCtx = document.getElementById('icsPieChart');
    var myPieChart = new Chart(pieCtx,{
      type: 'pie',
      data: {
        datasets: [{
            data: [10, 20, 30],
            backgroundColor:["#1f77b4","#ff7f0e","#2ca02c"]
        }],
        labels: [
            'TDMS',
            'IPSS',
            'ADW'
        ]
      }
    });

    const barCtx = document.getElementById('icsBarChart');
    var myBarChart = new Chart(barCtx, {
      type: 'bar',
      data: {
        labels:["12AM - 6AM","6AM - 12PM","12PM - 6PM","6PM - 12AM"],
        datasets:[{
          label:"Success",
          data:[1,2,3,4],
          backgroundColor:"rgb(50, 205, 50)"
        },{
          label:"InProgerss",
          data:[2,3,4,5],
          backgroundColor:"rgb(255, 215, 64)"
        },{
          label:"Failed",
          data:[3,4,5,6],
          backgroundColor:"rgb(255, 0,0)"
        }]        
      },
      options:{
        scales:{
          yAxes:[{
            ticks:{
              beginAtZero:true
            }
          }]
        }
      }
    });

    var stackedLabels=[];
    var successData=[];
    var inprogressData=[];
    var failedData=[];
    for(var _i=1;_i<=30;_i++){
      stackedLabels.push("IPSS"+_i);
      successData.push(_i);
      inprogressData.push(_i);
      failedData.push(_i);
    }
    stackedLabels.push("");
    successData.push(0);
    inprogressData.push(0);
    failedData.push(0);
    for(var _i=0;_i<=30;_i++){
      stackedLabels.push("ADW"+_i);
      successData.push(_i+3);
      inprogressData.push(_i+3);
      failedData.push(_i+3);
    }
    stackedLabels.push("");
    successData.push(0);
    inprogressData.push(0);
    failedData.push(0);
    for(var _i=0;_i<=30;_i++){
      stackedLabels.push("TDMS"+_i);
      successData.push(_i+1);
      inprogressData.push(_i+1);
      failedData.push(_i+1);
    }
    const stackedBarCtx = document.getElementById('icsHistBarChart');
    var stackedBar = new Chart(stackedBarCtx, {
        type: 'bar',
        data: {
          labels:stackedLabels,
          datasets:[
            {
              label: 'Success',
              data: successData,
              backgroundColor:"rgb(50, 205, 50)"
            },
            {
              label: 'InProgress',
              data: inprogressData,
              backgroundColor: "rgb(255, 215, 64)"
            },
            {
              label: 'Failed',
              data: failedData,
              backgroundColor: "rgb(255, 0,0)"
            }
          ]
        },
        options: {
            scales: {
                xAxes: [{
                    stacked: true,
                    gridLines: {
                      drawOnChartArea: false,
                      drawTicks:false
                    },
                    ticks:{
                      autoSkip: false,
                      callback:function(label){
                        if(label.indexOf("15")!=-1){
                          return label;
                        }
                        return "";
                      }
                    }
                }],
                yAxes: [{
                    stacked: true
                }]
            }
        }
    });

    const numbers = timer(0, 600000);
    numbers.subscribe((x: any) => {
      /**
     *  Api service call to get list of jobs
     */
      this.apiService.getAccessToken().subscribe((data: any) => {
        localStorage.setItem(appConstants.userToken, data.access_token);
        this.apiService.get(appConstants.apiUrls.getAllJobDetails)
          .subscribe((data: any) => {
            //this.loading = true;
            //data = res.json();
            this.dashboardModel.jobs = data["jobDetails"] as string[];	 // FILL THE ARRAY WITH DATA.
            this.dashboardModel.filteredJobs = data["jobDetails"] as string[];
            this.dashboardModel.totalCnt = data["TotalJobs"] as number;
            this.dashboardModel.successCnt = data["SuccessCount"] as number;
            this.dashboardModel.issuesCnt = data["IssuesCount"] as number;
            this.dashboardModel.filterData = data["filters"] as string[];
            this.dashboardModel.inprogressCnt = this.dashboardModel.totalCnt - this.dashboardModel.successCnt - this.dashboardModel.issuesCnt;
            this.memChart.data.datasets.forEach((dataset) => {
              dataset.data=[];
              dataset.data.push(this.dashboardModel.successCnt);
              dataset.data.push(this.dashboardModel.issuesCnt);
              dataset.data.push(this.dashboardModel.inprogressCnt);
            });
            this.memChart.update(0);
            this.loading = false;
          }, (err: any) => {
            this.loading = false;
            //to be implemented
          });
      },
        (err: any) => {
          //to be implemented
        });      
    });
    /* Pie chart Configuration  end*/
  }
  /* Goto next step*/
  setStep(index: number) {
    this.step = index;
  }
  /* Icon click */
  nextStep(job: any) {
		this.apiService.serviceData = job;
		this.router.navigate(['/dashboard/jobDetails']); 
	}
  /* Get Filtered Jobs */
  filterSelected(selectedOptions: any[], filterParent: string) {
    if (filterParent == appConstants.filterParent.status) {
      this.statusFilter = selectedOptions.map(x => x["value"]);
    }
    else if (filterParent == appConstants.filterParent.frequency) {
      this.frequencyFilter = selectedOptions.map(x => x["value"]);
    }
    else {
      this.systemFilter = selectedOptions.map(x => x["value"]);
    }

    if (this.dashboardModel.jobs != null) {
      let testJobs = this.dashboardModel.jobs;
      if (this.statusFilter.length > 0) {
        testJobs = testJobs.filter
          (e => (this.statusFilter.indexOf(e[appConstants.filter.status]) != -1));
      }
      if (this.frequencyFilter.length > 0) {
        testJobs = testJobs.filter
          (e => (this.frequencyFilter.indexOf(
            e[appConstants.filter.frequency] == appConstants.jobFrequencies.multiple ?
              e[appConstants.filter.frequency] : appConstants.jobFrequencies.nonMultiple) != -1
          ));
      }
      if (this.systemFilter.length > 0) {
        testJobs = testJobs.filter
          (e => (this.systemFilter.indexOf(e[appConstants.filter.source]) != -1)
            || (this.systemFilter.indexOf(e[appConstants.filter.target]) != -1));
      }
      this.dashboardModel.filteredJobs = testJobs;
    }
    this.setStep(1);
  }
}
