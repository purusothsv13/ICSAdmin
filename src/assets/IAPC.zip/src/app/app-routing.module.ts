import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PageNotFoundComponent }    from './not-found.component';

const appRoutes: Routes = [
    {
      path: 'dashboard',
      loadChildren: './dashboardICS/dashboardICS.module#DashboardModule'
    },
    {
      path: 'process-history',
      loadChildren: './process-history/process-history.module#ProcessHistoryModule'
    },
    {
      path: 'email-notification',
      loadChildren: './email-notification/email-notification.module#EmailNotificationModule'
    },
    {
      path: 'reports',
      loadChildren: './reports/reports.module#ReportsModule'
    },
    {
      path: 'user-management',
      loadChildren: './user-management/user-management.module#UserManagementModule'
    },
    { path: '',   redirectTo: '/dashboard', pathMatch: 'full' },
    { path: '**', component: PageNotFoundComponent }
];

@NgModule({
    imports: [
      RouterModule.forRoot(
        appRoutes,
        {
          //enableTracing: true, // <-- debugging purposes only
  
        }
      )
    ],
    exports: [
      RouterModule
    ]
  })
  export class AppRoutingModule { }
  