﻿function employees() {
    var uri = '../api/GetEmployees';
    $.getJSON(uri)
        .done(function (data) {
            $.each(data, function (key, item) {
                if (item.status == "Present")
                    $("#divPresentMP").html(item.count);
                else
                    $("#divAbsentMP").html(item.count);
            });
        });
}

function machines() {
    var macArray = [];
    var uri = '../api/GetMachineCount';
    $.getJSON(uri)
        .done(function (data) {
            $("#divMachineCount").html(data[0].total);
            $.each(data, function (key, item) {
                if (item.status == "Operational")
                    $("#spOperational").html(item.count);
                else if (item.status == "Cleaning")
                    $("#spCleaning").html(item.count);
                else
                    $("#spUnderMaintenance").html(item.count);
                macArray[key] = item.percentage;
            });

            var config = {
                type: 'doughnut',
                data: {
                    datasets: [{
                        data: [macArray[1], macArray[2], macArray[0]],
                        backgroundColor: ['#00cbff', '#e9e7fe', '#fe349a'],
                        borderColor: ['#00cbff', '#e9e7fe', '#fe349a'],
                        label: 'Dataset 1'
                    }],
                    labels: [
                        'Operational',
                        'Under Maintenance',
                        'Cleaning'
                    ]
                },
                options: {
                    responsive: true,
                    legend: {
                        display: false
                    },
                    title: {
                        display: false
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    },
                    tooltips: {
                        enabled: false
                    },
                    cutoutPercentage: 80
                }
            };
            var ctx = document.getElementById('chart-area').getContext('2d');
            window.myDoughnut = new Chart(ctx, config);            
        });

    var effect = 0;
    uri = '../api/GetMachineEffectiveness';
    $.getJSON(uri)
        .done(function (data) {
            $.each(data, function (key, item) {
                if (item.status == "Availabilty")
                    $("#span_availability").html(item.count);
                else if (item.status == "Quality")
                    $("#span_quality").html(item.count);
                else
                    $("#span_performance").html(item.count);
                effect = effect + item.count;
            });
            
            $('#progress_effectiveness').css('width', data[0].total + '%').attr('aria-valuenow', data[0].total);
            $('#progress_effectiveness').parent().parent().find('.progress_val').text(data[0].total + '%');

        });

    var uri = '../api/GetMachineDetails';
    $.getJSON(uri)
        .done(function (data) {
            $("#spTmpRise").html(data[0].temp_rise +"&deg;");
            $("#spEffDown").html(data[0].efficiency_down);
            $("#divMacOperator").html(data[0].m_operator);
        });
}

function shipment() {
    var uri = '../api/GetShipmentVehicles';
    $.getJSON(uri)
        .done(function (data) {
            $.each(data, function (key, item) {
                if (item.status == "AGV")
                    $("#spAGV").html(item.count);
                else
                    $("#spTruck").html(item.count);                
            });
        });
    var uri = '../api/GetShipmentSmartCont';
    $.getJSON(uri)
        .done(function (data) {
            $("#spTotalSC").html(data[0].total);
            $.each(data, function (key, item) {
                if (item.status == "In Campus")
                    $("#spInCampus").html(item.count);
                else if(item.status == "Out Campus")
                    $("#spOutCampus").html(item.count);
                else if (item.status == "Tampered")
                    $("#spTampered").html(item.count);
                else 
                    $("#spInActive").html(item.count);
            });
        });
}

function ingredients() {
    var uri = '../api/GetRawMaterials';
    $.getJSON(uri)
        .done(function (data) {
            $.each(data, function (key, item) {
                if (item.status == "Dry") {
                    $("#divDrySIHPerc").html(item.count + '%');
                    $("#divDrySIHProgress").width(item.count + '%');
                }
                else {
                    $("#divColdSIHPerc").html(item.count + '%');
                    $("#divColdSIHProgress").width(item.count + '%');
                }
            });
        });
}

function packages() {
    var uri = '../api/GetPackages';
    $.getJSON(uri)
        .done(function (data) {
            $.each(data, function (key, item) {
                if (item.product_name == "Chocolate Chip") {
                    if (item.size == "10 gm") {
                        $("#divChocSize1").html(item.size);
                        $("#divChocProgress1").html(item.no_of_packs_done + " of " + item.no_of_packs_req + " Boxes");                        
                        $("#divChocProgBar1").width(item.percentage + '%');
                    }
                    else {
                        $("#divChocSize2").html(item.size);
                        $("#divChocProgress2").html(item.no_of_packs_done + " of " + item.no_of_packs_req + " Boxes");
                        $("#divChocProgBar2").width(item.percentage + '%');
                    }
                } else {
                    if (item.size == "10 gm") {
                        $("#divMikaSize1").html(item.size);
                        $("#divMikaProgress1").html(item.no_of_packs_done + " of " + item.no_of_packs_req + " Boxes");
                        $("#divMikaProgBar1").width(item.percentage + '%');
                    }
                    else {
                        $("#divMikaSize2").html(item.size);
                        $("#divMikaProgress2").html(item.no_of_packs_done + " of " + item.no_of_packs_req + " Boxes");
                        $("#divMikaProgBar2").width(item.percentage + '%');
                    }
                }
            });        
        });
}

function batchDetails() {
    var uri = '../api/GetBatchDetails';
    $.getJSON(uri)
        .done(function (data) {
            $.each(data, function (key, item) {
                if (item.product_name == "Chocolate Chip") {
                    if (item.batch_no == 1) {
                        $("#time_01").html(item.hrs_to_complete);
                        $("#rate_01").html(item.rejection_rate);
                        $("#progress_01").width(item.perc_completed);
                        $("#spPercComp_01").html(item.perc_completed);
                        $("#divBatchTxt_01").html("Batch " + item.batch_no + " - " + item.batch_size);
                    }
                    else {
                        $("#time_02").html(item.hrs_to_complete);
                        $("#rate_02").html(item.rejection_rate);
                        $("#progress_02").width(item.perc_completed);
                        $("#spPercComp_02").html(item.perc_completed);
                        $("#divBatchTxt_02").html("Batch " + item.batch_no + " - " + item.batch_size);
                    }
                } else {
                    if (item.batch_no == 1) {
                        $("#time_03").html(item.hrs_to_complete);
                        $("#rate_03").html(item.rejection_rate);
                        $("#progress_03").width(item.perc_completed);
                        $("#spPercComp_03").html(item.perc_completed);
                        $("#divBatchTxt_03").html("Batch " + item.batch_no + " - " + item.batch_size);
                    }
                }

                //////////////////////////

                var valeur_1 = 0;
	            var time_1 = 10;
	            var rate_1 = 6;
	            setInterval(function(){
	            	if(valeur_1 < 100){
	            		valeur_1 = valeur_1 + 10;
	            		time_1 = '0' + (time_1 - 1);
	            		if(rate_1 < 2){
	            			rate_1 = 6;
	            		}
	            		rate_1 = '0' + (rate_1 - 1);
	            	}else{
	            		valeur_1 = 0;
	            		time_1 = 10;
	            		rate_1 = 6;
	            	}
	            	updateProgress(valeur_1, time_1, rate_1, '01');
	            }, 5000);	

	            var valeur_2 = 0;
	            var time_2 = 10;
	            var rate_2 = 6;
	            setInterval(function(){
	            	if(valeur_2 < 100){
	            		valeur_2 = valeur_2 + 10;
	            		time_2 = '0' + (time_2 - 1);
	            		if(rate_2 < 2){
	            			rate_2 = 6;
	            		}
	            		rate_2 = '0' + (rate_2 - 1);
	            	}else{
	            		valeur_2 = 0;
	            		time_2 = 10;
	            		rate_2 = 6;
	            	}
	            	updateProgress(valeur_2, time_2, rate_2, '02');
	            }, 7500);

	            var valeur_3 = 0;
	            var time_3 = 10;
	            var rate_3 = 6;
	            setInterval(function(){
	            	if(valeur_3 < 100){
	            		valeur_3 = valeur_3 + 10;
	            		time_3 = '0' + (time_3 - 1);
	            		if(rate_3 < 2){
	            			rate_3 = 6;
	            		}
	            		rate_3 = '0' + (rate_3 - 1);
	            	}else{
	            		valeur_3 = 0;
	            		time_3 = 10;
	            		rate_3 = 6;
	            	}
	            	updateProgress(valeur_3, time_3, rate_3, '03');
	            }, 12000);

	            function updateProgress(valeur, time, rate, count){
	            	$('#progress_'+ count).css('width', valeur+'%').attr('aria-valuenow', valeur);
	            	$('#progress_'+ count).parent().parent().find('.progress_val').text(valeur+'%');

	            	$('#time_'+ count).text(time+' Hrs');
	            	$('#rate_'+ count).text(rate+'%');
	            }
            });
        });
}

function machineDetails() {
    var uri = '../api/GetMachineDetails';
    $.getJSON(uri)
        .done(function (data) {
            $("#divMacNameHead").html("SORTING - Machine Name - " + data[0].machine_name);
            $("#divMEfficiency").html(data[0].efficiency+ "%");
            $("#spMAvailability").html(data[0].availability + "%");
            $("#spMQuality").html(data[0].quality + "%");
            $("#spMPerformance").html(data[0].performance + "%");
            $("#divMPerformance").html(data[0].performance + "%"); 

            $("#spMTemp").html(data[0].temperature); 
            $("#spMVibr").html(data[0].vibration);
            $("#spMBeltSpeed").html(data[0].belt_speed);
            $("#spMMotorSpeed").html(data[0].motor_speed);
            $("#spMHumidity").html(data[0].humidity);
            $("#spMGoodCount").html(data[0].good_count);
            $("#spMPendCount").html(data[0].pending_count);
            $("#spMNxMainDays").html(data[0].nxt_maint_days);
            $("#spMRunning").html(data[0].running == false ? "False" : "True");
            $("#spMOnline").html(data[0].online == false ? "False" : "True");

            var config_efficiency = {
                type: 'doughnut',
                data: {
                    datasets: [{
                        data: [data[0].efficiency, (100 - data[0].efficiency)],
                        backgroundColor: ['#00ccff', '#0a1115'],
                        borderColor: ['#00ccff', '#0a1115'],
                        label: 'Dataset 1'
                    }],
                    labels: [
                        'Blue',
                        'Black'
                    ]
                },
                options: {
                    responsive: true,
                    legend: {
                        display: false
                    },
                    title: {
                        display: false
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    },
                    tooltips: {
                        enabled: false
                    },
                    cutoutPercentage: 80
                }
            };
            var ctx_1 = document.getElementById('chart-area-efficiency').getContext('2d');
            window.myDoughnut = new Chart(ctx_1, config_efficiency);
            
        });
    var uri = '../api/GetMachineAttenders';
    $.getJSON(uri)
        .done(function (data) {            
            $("#spOperInc").html(data.operator_inc);
            $("#spAssiTech").html(data.assigned_tech);
            $("#spNoOfAttendee").html(data.no_of_attendee);
        });
}