import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ApiService } from '../../service/api.service';
import { dashboardModel } from '../dashboardICS.model';
import { appConstants } from '../../app.constants';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-jobDetails.',
  templateUrl: './jobDetails.component.html',
  styleUrls: ['../dashboardICS.component.css']
})

export class JobDetailsComponent implements OnInit {
  jobs:any;
  jobFrequency: string;
  jobName: string;
  scheduledTime: string;
  endDate: string;
  public dashboardModel: dashboardModel;
  constants = appConstants;
  public loading = false;
  get data(): string {
    return this.dataService.serviceData;
  }
  set data(value: string) {
    this.dataService.serviceData = value;
  }
  childSampleData: string = "Some child Data";
  constructor(public dataService: ApiService, private router: ActivatedRoute) { 
    this.dashboardModel = new dashboardModel();
    this.jobs = this.dataService.serviceData;
  }
  ngOnInit() {    
    this.jobFrequency=this.jobs.FREQUENCY;
    this.jobName = this.jobs.JOBNAME;
    this.scheduledTime = this.jobs.LASTSCHEDULEDDATE;
    this.endDate = this.jobs.STATUSDATE;
    if (this.jobFrequency != null && this.jobName != null) {
      //if (this.step != 2) {
      if (this.jobFrequency == appConstants.jobFrequencies.multiple) {
        this.childInstancesDetails(this.jobName);        
      }
      else {
        this.processLogdetails(this.jobName, this.scheduledTime, this.endDate);
      }
      // }
      // else {
      //   this.processLogdetails(this.jobName, this.scheduledTime, this.endDate);
      //   this.setStep(3);
      // }
    }
  }
  /* Get Child Instance data */
  childInstancesDetails(jobName: string) {
    this.loading = true;
    /*
      Api service call to get list of childinstances using jobName
    */
    //let data: any[];
    let params = {};
    params[appConstants.apiParams.jobName] = jobName;
    this.dataService.get(appConstants.apiUrls.getChildInstances, { params: params })
      .subscribe((data: any) => {
        this.loading = false;
        //data = res.json();
        this.dashboardModel.childJobs = data as string[];
        this.processLogdetails(this.jobName, this.scheduledTime, this.endDate);
      },
      (err: any) => {
        this.loading = false;
        console.log(err.message);
        //error handling to be implemented
      }
      );
  }

  /* Get Process Log details */
  processLogdetails(jobName: string, startDate: string, endDate: string) {
    this.loading = true;
    this.dashboardModel.processName = jobName;
    /*
      Api service call to process log details
    */
    let data: any[];
    let params = {};
    params[appConstants.apiParams.jobName] = jobName;
    params[appConstants.apiParams.startDate] = startDate;
    params[appConstants.apiParams.endDate] = endDate;
    //let latest_date =this.datepipe.transform(scheduledTime, 'dd-MMM-yyyy HH.mm.ss a');
    this.dataService.get(appConstants.apiUrls.getLogDetails, { params: params })
      .subscribe((data: any) => {
        this.loading = false;
        //data = res.json();      
        if (data != null) {
          data["processLogs"].forEach(item => {
            if (item.pl_Status == 'B')
              item.pl_Status = appConstants.jobStatus.started;
            if (item.pl_Status == 'E')
              item.pl_Status = appConstants.jobStatus.ended;
            if (item.pl_Status == 'F')
              item.pl_Status = appConstants.jobStatus.failed;
          });
          this.dashboardModel.processlogs = data["processLogs"] as string[];
          this.dashboardModel.sessionId = data["processLogs"][0].pl_Session_Id as number;
          this.dashboardModel.errorLogs = data["errorLogs"] as string[];
        }
      }, (err: any) => {
        this.loading = false;
        //error handling to be implemented
        console.log(err.message);
      }
      );
  }
}
