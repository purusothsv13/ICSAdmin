import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class ApiService {
  serviceData: string;
  constructor(private http: HttpClient) {
  }

  getAccessToken() {
    var data = "grant_type=password&username="+environment.apiUserName+"&password="+environment.apiPassword; 
    var reqHeader = new HttpHeaders({'No-Auth':'True' });
    return this.http.post(environment.apiUrl + '/token', data, {headers:reqHeader});
  }
  get(url: string, options?: any) {
    url = this.updateUrl(url);
    return this.http.get<Observable<Object>>(url, options);
  }

  post(url: string, body: string, options?: any) {
    url = this.updateUrl(url);
    return this.http.post<Observable<Object>>(url, body, options);
  }

  private updateUrl(req: string) {
    return environment.apiUrl + environment.apiController +req;
  }

  private handleError (error: Response | any) {
    console.error('ApiService::handleError', error);
    return Observable.throw(error);
  }  
}
