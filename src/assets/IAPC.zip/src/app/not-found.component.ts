import { Component } from '@angular/core';

@Component({
  template: '<div style="min-height:100%;">Page not found</div>'
})
export class PageNotFoundComponent {}
