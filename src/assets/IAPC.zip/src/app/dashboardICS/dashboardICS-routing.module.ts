import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent }    from './dashboardICS.component';
import { JobDetailsComponent } from 'src/app/dashboardICS/jobDetails/jobDetails.component';

const dashboardRoutes: Routes = [
  { path: '',  component: DashboardComponent },  
  { path: 'jobDetails',  component: JobDetailsComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(dashboardRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class DashboardRoutingModule { }
