import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { EmailNotificationComponent } from './email-notification.component';

const emailNotificationRoutes: Routes = [
  { path: '',  component: EmailNotificationComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(emailNotificationRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class EmailNotificationRoutingModule { }
