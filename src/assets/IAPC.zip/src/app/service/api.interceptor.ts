import { HttpInterceptor, HttpRequest, HttpHandler, HttpUserEvent, HttpEvent } from "@angular/common/http";
import { Observable } from 'rxjs';
import { Injectable } from "@angular/core";
import { ApiService } from "src/app/service/api.service";

@Injectable()
export class ApiInterceptor implements HttpInterceptor {

    constructor(private apiService: ApiService) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (req.headers.get('No-Auth') == "True")
        {
            const clonedreq = req.clone({
                headers: req.headers.delete('No-Auth')
            });
            return next.handle(clonedreq);
        }
        if (localStorage.getItem('userToken') != null) {
            const clonedreq = req.clone({
                headers: req.headers.set("Authorization", "Bearer " + localStorage.getItem('userToken'))
            });
            return next.handle(clonedreq);
        }
        else {
            this.apiService.getAccessToken().subscribe((data : any)=>{
                localStorage.setItem('userToken',data.access_token);
                const clonedreq = req.clone({
                    headers: req.headers.set("Authorization", "Bearer " + localStorage.getItem('userToken'))
                });
                return next.handle(clonedreq);
              },
              (err : any)=>{
                //to be implemented
              });
        }
    }
}