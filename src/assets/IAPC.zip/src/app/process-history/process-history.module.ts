import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProcessHistoryComponent } from '../process-history/process-history.component';
import { ProcessHistoryRoutingModule } from '../process-history/process-history-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ProcessHistoryRoutingModule
  ],
  declarations: [ProcessHistoryComponent]
})
export class ProcessHistoryModule { }
