import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-process-history',
  templateUrl: './process-history.component.html',
  styleUrls: ['./process-history.component.css']
})
export class ProcessHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
