import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ProcessHistoryComponent } from '../process-history/process-history.component';

const processHistoryRoutes: Routes = [
  { path: '',  component: ProcessHistoryComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(processHistoryRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class ProcessHistoryRoutingModule { }
