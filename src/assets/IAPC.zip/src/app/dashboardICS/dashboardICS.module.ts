import { CommonModule }   from '@angular/common';
import { NgModule } from '@angular/core';
import { MatExpansionModule, MatSidenavModule,MatIconModule,MatButtonModule,MatListModule } from '@angular/material';

import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http'; 
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoadingModule } from 'ngx-loading';
import { DashboardComponent }    from './dashboardICS.component';
import { JobDetailsComponent } from './jobDetails/jobDetails.component';
import { DashboardRoutingModule }    from './dashboardICS-routing.module';
import { ApiService } from '../../app/service/api.service';
import { ApiInterceptor } from '../../app/service/api.interceptor';

@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatExpansionModule,
    MatSidenavModule,
    MatIconModule,
    MatButtonModule,    
    MatListModule,
    HttpModule,
    HttpClientModule,    
    NgbModule.forRoot(),
    LoadingModule.forRoot({
      backdropBorderRadius: '0px',
      primaryColour: '#ffffff', 
      secondaryColour: '#ffffff', 
      tertiaryColour: '#ffffff',
      fullScreenBackdrop:true
  })
  ],
  declarations: [
    DashboardComponent,
    JobDetailsComponent     
  ],
  providers:[ApiService,
    {
    provide : HTTP_INTERCEPTORS,
    useClass : ApiInterceptor,
    multi : true
  }]
})
export class DashboardModule {}
