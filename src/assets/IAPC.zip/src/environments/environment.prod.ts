export const environment = {
  production: true,
  // URL of production API
  apiUrl: 'https://10.81.49.83:442',
  apiController: '/api/IcsAdmin',
  apiUserName:'icsadmin',
  apiPassword:'@icsadmin'
};
